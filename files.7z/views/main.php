<?php
echo $test;